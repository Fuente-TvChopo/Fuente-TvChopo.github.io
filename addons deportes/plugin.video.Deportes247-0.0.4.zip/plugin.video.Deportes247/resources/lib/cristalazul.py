# -*- coding: utf-8 -*-
import urllib2,urllib
import re,time
import time,json,base64
import cookielib,aes,os
import xbmc
import sys,re,os
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin

  return 'plugin://plugin.video.cristalazul'