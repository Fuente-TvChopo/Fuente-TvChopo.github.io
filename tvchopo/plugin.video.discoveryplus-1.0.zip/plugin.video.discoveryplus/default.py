# -*- coding: utf-8 -*-
#------------------------------------------------------------
# chopodplay - XBMC Add-on by Torete
# Version 0.2.5 (15.05.2014)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)


import os
import sys
import urllib
import urllib2
import re
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import plugintools
import unicodedata
import base64
import requests
import shutil
import base64
import time




addon = xbmcaddon.Addon()
addonname = '[B][LOWERCASE][CAPITALIZE][COLOR white]chopo[COLOR gold]dplay[/CAPITALIZE][/LOWERCASE][/B][/COLOR]'
icon = addon.getAddonInfo('icon')
myaddon = xbmcaddon.Addon("plugin.video.discoveryplus")
Set_Color = myaddon.getSetting('SetColor')
Set_View = myaddon.getSetting('SetView')
local_remote = urllib2.urlopen(urllib2.Request("https://pastebin.com/raw/4bycJGMs")).read()
version = '1'
parakodi18='parakodi18'
parakodi19='noes'
def run():
    
    plugintools.log("---> chopodplay.run <---")
    plugintools.set_view(plugintools.LIST)
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
       action = params.get("action")
       url = params.get("url")
       exec action+"(params)"

    plugintools.close_item_list()


#---------MENU PRINCIPAL-----------------------MENU PRINCIPAL----------------------------MENU PRINCIPAL---------------------------------------
#---------MENU PRINCIPAL-----------------------MENU PRINCIPAL----------------------------MENU PRINCIPAL---------------------------------------
#---------MENU PRINCIPAL-----------------------MENU PRINCIPAL----------------------------MENU PRINCIPAL---------------------------------------#---------MENU PRINCIPAL-----------------------MENU PRINCIPAL----------------------------MENU PRINCIPAL---------------------------------------#---------MENU PRINCIPAL-----------------------MENU PRINCIPAL----------------------------MENU PRINCIPAL---------------------------------------#---------MENU PRINCIPAL-----------------------MENU PRINCIPAL----------------------------MENU PRINCIPAL---------------------------------------#---------MENU PRINCIPAL-----------------------MENU PRINCIPAL----------------------------MENU PRINCIPAL---------------------------------------#---------MENU PRINCIPAL-----------------------MENU PRINCIPAL----------------------------MENU PRINCIPAL---------------------------------------#---------MENU PRINCIPAL-----------------------MENU PRINCIPAL----------------------------MENU PRINCIPAL---------------------------------------


def updated_color():
    if version == local_remote:
        return "[B][LOWERCASE][CAPITALIZE][COLOR lime]base actualizada version "+version+"[/CAPITALIZE][/LOWERCASE][/B][/COLOR]"
    else:
        return "[B][LOWERCASE][CAPITALIZE][COLOR red]base desactualizada sal del addon y vuelve a entrar[/CAPITALIZE][/LOWERCASE][/B][/COLOR]"
updated = updated_color()
    

   

def main_list(params):
    plugintools.log("chopodplay.main_list ")    
    plugintools.set_view(plugintools.LIST)  

    plugintools.add_item(action = "" , title =updated, thumbnail ="", fanart = "",  folder = False )
     
    plugintools.add_item(action = "" , title ="[B][LOWERCASE][CAPITALIZE][COLOR fuchsia]ADDON VALIDO PARA KODI 18 Y 19[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://4.bp.blogspot.com/-ATMEE7v7VsE/XFAEF62FZoI/AAAAAAAAuHc/vfUrZZvZX1IQVoo1cnxINpQXBVIQaXhAgCLcBGAs/s1600/kodi-18-oficial.jpg", fanart = "https://1.bp.blogspot.com/-j1_ehVPKRnA/XzFqgsyU45I/AAAAAAABmjw/5OEuwok_VLoUBnh7NOe6RjbmFjEqkiWlgCLcBGAsYHQ/s1600/kodi-19-alfa-descarga.jpg",  folder = False ) 
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )
 
 
    plugintools.add_item(action = "menu_principal" , title = "[B][LOWERCASE][CAPITALIZE][COLOR white]crimenes y misterios[/CAPITALIZE][/LOWERCASE][/B][/COLOR]",thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://i.imgur.com/Jj8EwmC.jpg",url = "https://disco-api.discoveryplus.es/cms/routes/genero/crimen?decorators=viewingHistory&include=default", folder = True )
 
 
    plugintools.add_item(action = "ultimoscapitulos" , title = "[B][LOWERCASE][CAPITALIZE][COLOR white]ultimos capis[/CAPITALIZE][/LOWERCASE][/B][/COLOR]",thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg", url="https://disco-api.dplay.es/cms/routes/ultimos-videos-anadidos-dplay?decorators=viewingHistory&include=default", folder = True )
 
    plugintools.add_item(action = "menu_principal" , title = "[B][LOWERCASE][CAPITALIZE][COLOR white]todos los programas[/CAPITALIZE][/LOWERCASE][/B][/COLOR]",thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://disco-api.dplay.es/cms/routes/series?decorators=viewingHistory&include=default", folder = True )    
   
    plugintools.add_item(action = "generos" , title = "[B][LOWERCASE][CAPITALIZE][COLOR white]generos[/CAPITALIZE][/LOWERCASE][/B][/COLOR]",thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://pastebin.com/raw/CeMJmWSW", folder = True )      
 
 
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+[COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )    
   
   
   
  
       
   
def generos(params):
    plugintools.log("chopodplay.clasicos_del_cine")
   
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+  generos[COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )
     
    url = params.get("url")
    def repro2(url):
         import re, requests
         url = url
         headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; rv:74.0) Gecko/20100101 Firefox/74.0', 'Referer': 'https://www.dplay.es/series/crimenes-en-la-red', 'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3', 'cookie' : 'st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6ZHBsYXllczo4NjFiZWVjMi1lNThiLTRiODktYWE0MC1hYzExZDE2YTUxNTkiLCJqdGkiOiJ0b2tlbi1mNmYzYzg1ZS03OTY2LTQ2NmQtYmRjZi1hNTMzYmRhMDBhNjUiLCJhbm9ueW1vdXMiOmZhbHNlLCJpYXQiOjE1OTM4NjA1MjF9.jGf7R1K8CCXEXywAusUQwRmQOpZSXe_L-vgxVh2D4eM'}    
         marcador = requests.get(url, headers=headers).content
         return marcador   
    link2=repro2(url)
    matches = plugintools.find_multiple_matches(link2,'(alias" : ".*?-link-default.*?state" : "published",)')  
    for generos in matches:
        url = "https://disco-api.dplay.es/cms/routes/genero/"+plugintools.find_single_match(generos,'alias" : "(.*?)-link-default')+"?decorators=viewingHistory&include=default"
        titulo= plugintools.find_single_match(generos,'"name" : "(.*?) link default')
        foto= plugintools.find_single_match(generos,'"src" : "(.*?)"')
        plugintools.add_item(action = "menu_principal" , title ="[B][LOWERCASE][CAPITALIZE][COLOR white]"+titulo+" [COLOR gold][/B][/COLOR][/CAPITALIZE][/LOWERCASE]", thumbnail =foto, fanart = foto, url =url,folder=True )
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+  generos[COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )    
   
   
   
   
    
    
    
def menu_principal(params):
    plugintools.log("chopodplay.menu_principal")   
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )
    thumbnail = params.get("thumbnail")
    url = params.get("url")
    def repro2(url):
         import re, requests
         url = url
         headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; rv:74.0) Gecko/20100101 Firefox/74.0', 'Referer': 'https://www.dplay.es/series/crimenes-en-la-red', 'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3', 'cookie' : 'st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6ZHBsYXllczo4NjFiZWVjMi1lNThiLTRiODktYWE0MC1hYzExZDE2YTUxNTkiLCJqdGkiOiJ0b2tlbi1mNmYzYzg1ZS03OTY2LTQ2NmQtYmRjZi1hNTMzYmRhMDBhNjUiLCJhbm9ueW1vdXMiOmZhbHNlLCJpYXQiOjE1OTM4NjA1MjF9.jGf7R1K8CCXEXywAusUQwRmQOpZSXe_L-vgxVh2D4eM'}    
         marcador = requests.get(url, headers=headers).content
         return marcador   
    link2=repro2(url)
    matches = plugintools.find_multiple_matches(link2,'("videoCount" :.*?alternateId" : ".*?"seasonNumbers")')
    for generos in matches:
        url = plugintools.find_single_match(generos,'alternateId" : "(.*?)".*?')
        titulo = plugintools.find_single_match(generos,'"hasNewEpisodes".*?"name" : "(.*?)".*?')
        texto = plugintools.find_single_match(generos,'"description" : "(.*?)".*?')       
        plugintools.add_item(action = "temporadas" , thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",title ="[B][LOWERCASE][CAPITALIZE][COLOR white]"+titulo+"[/CAPITALIZE][/LOWERCASE][/B][/COLOR]",plot="1",  url =url, folder=True )       
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )
   
 
def temporadas(params):
    plugintools.log("chopodplay.clasicos_del_cine")
   
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )
    thumbnail = params.get("thumbnail") 
    url = params.get("url")
    numero = params.get("plot")
    def tempo(url):
        import re, requests
        url = 'https://disco-api.dplay.es/cms/routes/series/'+url+'?decorators=viewingHistory&include=default'
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; rv:77.0) Gecko/20100101 Firefox/77.0","Accept": "*/*","Accept-Language": "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3", "Referer": "https://www.dplay.es/series/"+url, "x-disco-client": "WEB:UNKNOWN:dplay-client:2.6.0","x-disco-params": "realm=dplayes","If-None-Match": "W/\"2862534429\"","Cache-Control": "max-age=0", "cookie" : "st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6ZHBsYXllczo4NjFiZWVjMi1lNThiLTRiODktYWE0MC1hYzExZDE2YTUxNTkiLCJqdGkiOiJ0b2tlbi1mNmYzYzg1ZS03OTY2LTQ2NmQtYmRjZi1hNTMzYmRhMDBhNjUiLCJhbm9ueW1vdXMiOmZhbHNlLCJpYXQiOjE1OTM4NjA1MjF9.jGf7R1K8CCXEXywAusUQwRmQOpZSXe_L-vgxVh2D4eM"}
        marcador = requests.get(url, headers=headers).content
        return marcador 
    link2=tempo(url)
    ids = plugintools.find_single_match(link2,'(?s)mandatoryParams" : "pf.show.id.=.*?".*?"id":"(.*?)"')
    ids2 = plugintools.find_single_match(link2,'mandatoryParams" : "pf.show.id.=(.*?)"')   

    
    matches = plugintools.find_multiple_matches(link2,'("parameter" : "pf.seasonNumber.=.*?".*?"value" : ".*?".*?)')
    for generos in matches:
        url = plugintools.find_single_match(generos,'parameter" : "(pf.seasonNumber.=.*?)".*?')
        titulo = plugintools.find_single_match(generos,'"value" : "(.*?)".*?')        
        final= 'https://disco-api.dplay.es/cms/collections/'+ids+'?decorators=viewingHistory&include=default&pf[show.id]='+ids2+'&pf[seasonNumber]='+titulo+'&page[items.number]='
                
        plugintools.add_item(action = "capitulos" , title = '[B][LOWERCASE][CAPITALIZE][COLOR white]temporada '+titulo+'[/CAPITALIZE][/LOWERCASE][/B][/COLOR]', thumbnail =thumbnail, fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg", url=final,plot='1',  folder = True )  
 
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )
def ultimoscapitulos(params):
    plugintools.log("chopodplay.capitulos")
 
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False ) 
    thumbnail = params.get("thumbnail")

    url5 = params.get("url")
    def tempo(url5):
        import re, requests
        url = url5
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; rv:77.0) Gecko/20100101 Firefox/77.0","Accept": "*/*","Accept-Language": "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3", "x-disco-client": "WEB:UNKNOWN:dplay-client:2.6.0","x-disco-params": "realm=dplayes","If-None-Match": "W/\"2862534429\"","Cache-Control": "max-age=0", "cookie" : "st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6ZHBsYXllczo4NjFiZWVjMi1lNThiLTRiODktYWE0MC1hYzExZDE2YTUxNTkiLCJqdGkiOiJ0b2tlbi1mNmYzYzg1ZS03OTY2LTQ2NmQtYmRjZi1hNTMzYmRhMDBhNjUiLCJhbm9ueW1vdXMiOmZhbHNlLCJpYXQiOjE1OTM4NjA1MjF9.jGf7R1K8CCXEXywAusUQwRmQOpZSXe_L-vgxVh2D4eM"}
        marcador = requests.get(url, headers=headers).content
        return marcador 
    link2=tempo(url5)
    matches = plugintools.find_multiple_matches(link2,'((?s)alternateId" : "temporada.*?".*?description" : ".*?"drmEnabled.*?"path" : ".*?".*?"id":".*?")')
    for generos in matches:
        patron = plugintools.find_single_match(generos,'(?s)alternateId" : "(temporada.*?)".*?description" : "(.*?)"drmEnabled.*?"path" : "(.*?)".*?"id":"(.*?)"')
        titulo = patron[2]
        description = patron[1]
        idss = patron[3]
        titulo2 = plugintools.find_single_match(generos,'"path" : "(.*?)".*?').replace('-',' ').replace('/',' ')
        plugintools.set_view(plugintools.MOVIES,503)
        
        plugintools.add_item(action = "reproducir" , title ='[B][LOWERCASE][CAPITALIZE][COLOR white]'+titulo+'[/CAPITALIZE][/LOWERCASE][/B][/COLOR]', plot='[B][LOWERCASE][CAPITALIZE][COLOR gold]'+description+'[/CAPITALIZE][/LOWERCASE][/B][/COLOR]', url =idss,thumbnail =thumbnail, fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",folder=False,  isPlayable = True ) 
        
        
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False ) 
def capitulos(params):
    plugintools.log("chopodplay.capitulos")
 
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )
    thumbnail = params.get("thumbnail")
    numero = params.get("plot")
    url4 = params.get("url")
    url5 = params.get("url")+numero
    def tempo(url5):
        import re, requests
        url = url5
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; rv:77.0) Gecko/20100101 Firefox/77.0","Accept": "*/*","Accept-Language": "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3", "x-disco-client": "WEB:UNKNOWN:dplay-client:2.6.0","x-disco-params": "realm=dplayes","If-None-Match": "W/\"2862534429\"","Cache-Control": "max-age=0", "cookie" : "st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6ZHBsYXllczphZGQ4MmM2NS0xYWRkLTRlMzUtOWQ3ZC1lY2Y4MjA4N2I1NjEiLCJqdGkiOiJ0b2tlbi1iNDUxODUwYS1mOWMzLTRkMzgtODlkZS1kZDk3ZTZlOTA5OTAiLCJhbm9ueW1vdXMiOmZhbHNlLCJpYXQiOjE2MDk4NjYxMjV9.hybSgrbfEZrknhKqaYU95CVXY6NHmizA30Y3C7yeoeI; AMCV_9AE0F0145936E3790A495CAA%40AdobeOrg=1585540135%7CMCMID%7C41973076553705022644357297677176080819%7CMCAAMLH-1610464935%7C6%7CMCAAMB-1610464935%7C6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y%7CMCOPTOUT-1609867335s%7CNONE…&geolocation=ES%3BAN&AwaitingReconsent=false; OptanonAlertBoxClosed=2021-01-05T15:22:23.676Z; eupubconsent-v2=CO_jSnLO_jSnLAcABBENBHCsAP_AAH_AACiQHONf_X_fb3_j-_59_9t0eY1f9_7_v-0zjgeds-8Nyd_X_L8X42M7vF36pq4KuR4Eu3LBIQdlHOHcTUmw6IkVrTPsbk2Mr7NKJ7PEinMbe2dYGH9_n9XTuZKY79_s___z__-__v__77f_r-3_3_vp9X---_e_QOXAJMNS-AizEscCSaNKoUQIQriQ6AUAFFCMLRNYQErgp2VwEfoIGACA1ARgRAgxBRiwCAAAAAJKIgJADwQCIAiAQAAgBUgIQAEaAILACQMAgAFANCwAigCECQgyOCo5TAgIkWignkjAEou9jDCEMosAKBR_QAAA.f_gAD_gAAAAA; _fbp=fb.1.1609860145176.1517831900"}
        marcador = requests.get(url, headers=headers).content
        return marcador 
    link2=tempo(url5)
    pagina = plugintools.find_single_match(link2,'"itemsCurrentPage" : (.*?)\n')
    siguiente = plugintools.find_single_match(link2,'"itemsTotalPages" : (.*?)\n')
    matches = plugintools.find_multiple_matches(link2,'(alternateId" : "temporada.*?".*?description" : ".*?"id":".*?images":{"data":.{"id":".*?".*?)')
    for generos in matches:
        titulo = plugintools.find_single_match(generos,'alternateId" : "(temporada.*?)".*?').replace('-',' ').replace('/',' ')
        description = plugintools.find_single_match(generos,'description" : "(.*?)".*?')
        idss = plugintools.find_single_match(generos,'"id":"(.*?)".*?')
        plugintools.set_view(plugintools.MOVIES,503)
        plugintools.add_item(action = "reproducir" , title ='[B][LOWERCASE][CAPITALIZE][COLOR white]'+titulo+'[/CAPITALIZE][/LOWERCASE][/B][/COLOR]', plot='[B][LOWERCASE][CAPITALIZE][COLOR gold]'+description+'[/CAPITALIZE][/LOWERCASE][/B][/COLOR]', url =idss,thumbnail =thumbnail, fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",folder=False,  isPlayable = True )
 
    if numero < siguiente:
        s="hola"        
        def dec(s):
            a = int("1")
            b = int(numero)
            suma = a+b
            return (str(suma))
        esto = dec(s)

   
        plugintools.add_item(action = "capitulos" , title ='[B][LOWERCASE][CAPITALIZE][COLOR lime]pagina siguiente [COLOR gold]'+esto+'[/CAPITALIZE][/LOWERCASE][/B][/COLOR]',plot=esto, thumbnail = "https://www.periodicoelpunto.com/wp-content/uploads/2019/03/flecha-siguiente.png",fanart = "https://www.periodicoelpunto.com/wp-content/uploads/2019/03/flecha-siguiente.png",  url =url4,folder=True )
        
        
        
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )
 
 
def reproducir(params):
    plugintools.log("chopodplay.clasicos_del_cine")
 
    plugintools.add_item(action = "" , title = "[B][LOWERCASE][CAPITALIZE][COLOR yellow]----------------- [COLOR orange] discovery+ [COLOR yellow]-----------------[/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://static.wikia.nocookie.net/logopedia/images/a/a6/Discovery_Plus_logo_%28stacked%29.png/revision/latest?cb=20201227091030", fanart = "https://www.exchange4media.com/news-photo/105426-image8.jpg",url="https://es.dplay.com/series/",   folder = False )
    thumbnail = params.get("thumbnail")
    url5 = 'https://disco-api.dplay.es/playback/v2/videoPlaybackInfo/'+params.get("url")+'?usePreAuth=true'
    def tempo(url5):
        import re, requests
        url = url5
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; rv:77.0) Gecko/20100101 Firefox/77.0","Accept": "*/*","Accept-Language": "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3", "x-disco-client": "WEB:UNKNOWN:dplay-client:2.6.0","x-disco-params": "realm=dplayes","If-None-Match": "W/\"2862534429\"","Cache-Control": "max-age=0", "cookie" : "st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6ZHBsYXllczphZGQ4MmM2NS0xYWRkLTRlMzUtOWQ3ZC1lY2Y4MjA4N2I1NjEiLCJqdGkiOiJ0b2tlbi1iNDUxODUwYS1mOWMzLTRkMzgtODlkZS1kZDk3ZTZlOTA5OTAiLCJhbm9ueW1vdXMiOmZhbHNlLCJpYXQiOjE2MDk4NjYxMjV9.hybSgrbfEZrknhKqaYU95CVXY6NHmizA30Y3C7yeoeI; AMCV_9AE0F0145936E3790A495CAA%40AdobeOrg=1585540135%7CMCMID%7C41973076553705022644357297677176080819%7CMCAAMLH-1610464935%7C6%7CMCAAMB-1610464935%7C6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y%7CMCOPTOUT-1609867335s%7CNONE…&geolocation=ES%3BAN&AwaitingReconsent=false; OptanonAlertBoxClosed=2021-01-05T15:22:23.676Z; eupubconsent-v2=CO_jSnLO_jSnLAcABBENBHCsAP_AAH_AACiQHONf_X_fb3_j-_59_9t0eY1f9_7_v-0zjgeds-8Nyd_X_L8X42M7vF36pq4KuR4Eu3LBIQdlHOHcTUmw6IkVrTPsbk2Mr7NKJ7PEinMbe2dYGH9_n9XTuZKY79_s___z__-__v__77f_r-3_3_vp9X---_e_QOXAJMNS-AizEscCSaNKoUQIQriQ6AUAFFCMLRNYQErgp2VwEfoIGACA1ARgRAgxBRiwCAAAAAJKIgJADwQCIAiAQAAgBUgIQAEaAILACQMAgAFANCwAigCECQgyOCo5TAgIkWignkjAEou9jDCEMosAKBR_QAAA.f_gAD_gAAAAA; _fbp=fb.1.1609860145176.1517831900"}
        marcador = requests.get(url, headers=headers).content
        return marcador 
    link2=tempo(url5)
    link = plugintools.find_single_match(link2,'(?s)hls".*? "url" : "(.*?)"')
    plugintools.play_resolved_url( link )
   
   
def play_links(params):
    try:  
        plugintools.play_resolved_url( params.get("url") )
 
    except:
        u= xbmc.executebuiltin('XBMC.Notification([B][LOWERCASE][CAPITALIZE][COLOR white]enlace  [COLOR red]borrado [/CAPITALIZE][/LOWERCASE][/B][/COLOR],[B][LOWERCASE][CAPITALIZE][COLOR white]elige otro [/CAPITALIZE][/LOWERCASE][/B][/COLOR], 4000)')
        plugintools.add_item(action = "servidores" , title = u,  folder = True )  
   
run()